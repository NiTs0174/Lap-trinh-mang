package udp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class Server extends javax.swing.JFrame {

    static final int PORT = 1234;
    private DatagramSocket socket = null;
    
    public Server() throws IOException {
        initComponents();
        socket = new DatagramSocket(PORT);
        System.out.println("Server dang chay");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnText = new javax.swing.JButton();
        txtKey = new javax.swing.JTextField();
        txtResult = new javax.swing.JTextField();
        btnBinary = new javax.swing.JButton();
        btnListen = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("KEY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("RESULT");

        btnText.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnText.setForeground(new java.awt.Color(255, 0, 51));
        btnText.setText("TEXT");
        btnText.setFocusable(false);
        btnText.setInheritsPopupMenu(true);
        btnText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTextActionPerformed(evt);
            }
        });

        txtKey.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtKey.setText("abcde vbnmcx uiopyq");
        txtKey.setToolTipText("");

        txtResult.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btnBinary.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnBinary.setForeground(new java.awt.Color(255, 51, 0));
        btnBinary.setText("BINARY");
        btnBinary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBinaryActionPerformed(evt);
            }
        });

        btnListen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnListen.setForeground(new java.awt.Color(255, 51, 51));
        btnListen.setText("RUN");
        btnListen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListenActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 153));
        jLabel3.setText("SERVER");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnListen)
                .addGap(15, 15, 15))
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(73, 73, 73))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(47, 47, 47)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtKey, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                            .addComponent(txtResult)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnText, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBinary, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)))
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnListen, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtKey, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtResult, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBinary, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnText, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//---------------------------------------------------------
    private void btnTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTextActionPerformed
        // TODO add your handling code here:
        try {
            byte[] receiveData = new byte[1024];
            byte[] receiveData1 = new byte[1024];
            byte[] sendData = new byte[1024];
            //Tạo gói tin nhận 
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            DatagramPacket receivePacket1 = new DatagramPacket(receiveData1, receiveData1.length);
            socket.receive(receivePacket1);

            String content = new String(receivePacket.getData());
            String path = new String(receivePacket1.getData()).trim();
            // lấy địa chỉ IP và số hiệu cồng bên gửi
            InetAddress IPAddress = receivePacket.getAddress();
            int port = receivePacket.getPort();

            System.out.println("path: " + path);
            System.out.println("content: " + content);
            //Kiểm tra đường dẫn - tạo file
            FileCheck(path);
            //Mã hóa
            String tam[] = content.split(" ");
            String mahoa = "";
            for (String string : tam) {
                mahoa += Encrypted(string, txtKey.getText()) + " ";
            }
            System.out.println("Ma hoa duoc la: " + mahoa);
            // ghi file văn bản
            textWrite(path, mahoa);
            //đọc từ file
            String str = textRead(path);
            System.out.println("Noi dung file duoc doc la: " + str);
            //Giải mã
            String[] temp = str.trim().split(" ");
            String arrInt = "";
            for (String string : temp) {
                arrInt += Decrypted(string, txtKey.getText()) + " ";
            }
            //hiển thị kết quả
            txtResult.setText(arrInt);
            System.out.println("Ket qua giai ma la: " + arrInt);  
            // gửi kết quả về cho client
            sendData = mahoa.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
            //Gửi gói tin đi
            socket.send(sendPacket);
        }catch (IOException ex) {
            System.out.println("Da xay ra loi!");
        }
    }//GEN-LAST:event_btnTextActionPerformed
//---------------------------------------------------------
    private void btnBinaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBinaryActionPerformed
        try {
            byte[] receiveData = new byte[1024];
            byte[] receiveData1 = new byte[1024];
            byte[] sendData = new byte[1024];
            //Tạo gói nhận tin
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            DatagramPacket receivePacket1 = new DatagramPacket(receiveData1, receiveData1.length);
            socket.receive(receivePacket1);

            String content = new String(receivePacket.getData());
            String path = new String(receivePacket1.getData()).trim();
            // lấy địa chỉ IP và số hiệu cồng bên gửi
            InetAddress IPAddress = receivePacket.getAddress();
            int port = receivePacket.getPort();

            System.out.println("path: " + path);
            System.out.println("content: " + content);
            //Kiểm tra đường dẫn - tạo file
            FileCheck(path);
            //Mã hóa
            String tam[] = content.split(" ");
            String mahoa = "";
            for (String string : tam) {
                mahoa += Encrypted(string, txtKey.getText()) + " ";
            }
            System.out.println("Ma hoa duoc la: " + mahoa);
            // ghi file văn bản
            binaryWrite(path, mahoa);
            //đọc từ file
            String str = binaryRead(path);
            System.out.println("Noi dung file doc duoc la: " + str);
            //Giải mã
            String[] temp = str.trim().split(" ");
            String arrInt = "";
            for (String string : temp) {
                arrInt += Decrypted(string, txtKey.getText()) + " ";
            }
            //hiển thị kết quả
            txtResult.setText(arrInt);
            System.out.println("Ket qua giai ma la: " + arrInt);
            // gửi kết quả về cho client
            sendData = mahoa.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
            //Gửi gói tin đi
            socket.send(sendPacket);
        }catch (IOException ex) {
            System.out.println("Da xay ra loi!");
        }
    }//GEN-LAST:event_btnBinaryActionPerformed
//---------------------------------------------------------
    private void btnListenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListenActionPerformed
        // TODO add your handling code here:
        try {
            byte[] receiveData = new byte[1024];
            byte[] sendData = new byte[1024];
            //Tạo gói tin nhận
            DatagramPacket receivePacket1 = 
                    new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket1);
            String content = new String(receivePacket1.getData()).trim();
            // lấy địa chỉ IP và số hiệu cồng bên gửi
            InetAddress IPAddress = receivePacket1.getAddress();
            int port = receivePacket1.getPort();
            System.out.println("content: " + content);
            if(content.equals("REQUEST")){       
                // gửi kết quả về cho client
                sendData = "ACCEPT".getBytes();
                DatagramPacket sendPacket = 
                        new DatagramPacket(sendData, sendData.length, IPAddress, port);
                //Gửi gói tin đi
                socket.send(sendPacket);
            }
        } catch (IOException ex) {
            System.out.println("Da xay ra loi!");
        }
    }//GEN-LAST:event_btnListenActionPerformed
//---------------------------------------------------------
    private void FileCheck(String addr) throws IOException {
        File f = new File(addr);
        if (f.exists()) {
            System.out.println("File da ton tai");
        } else {
            f.createNewFile();
            System.out.println("File da duoc tao!");
        }
    }
//---------------------------------------------------------
    private String Encrypted(String plaintext, String keyword) throws IOException {        
        StringBuilder encryptedMessage = new StringBuilder();//tạo chuỗi chứa
        //duyệt các ký tự
        for (int i = 0, j = 0; i < plaintext.length(); i++) { 
            char c= plaintext.charAt(i);
            ////Kiểm tra xem ký tự là chữ cái in thường
            if (Character.isLetter (c)) { 
                char base = 'a';
                char keyChar = keyword.charAt(j);
                //Kiểm tra xem ký tự là chữ cái in hoa
                if (Character.isUpperCase (c)){
                    base = 'A';
                    keyChar = Character.toUpperCase(keyChar);
                }
                //Đưa về chữ cái in thường
                else {
                    keyChar = Character.toLowerCase(keyChar);
                }
                //thêm vào chuỗi mã hóa
                //(c + keyChar - 2 * base) chuyển đổi ký tự về số nguyên khoảng 0-25, tương ứng với bảng chũ cái
                //(c + keyChar - 2 * base) % 26+ base) lấy phần dư, công thêm base để chuyển về mã ASCII
                char encryptedChar = (char) ((c + keyChar - 2 * base) % 26+ base); 
                encryptedMessage.append(encryptedChar);
                //duyệt từng ký tự
                j = (j + 1) % keyword.length();
            } else {
                // Giữ nguyên ký tự nếu không phải là chữ cái
                encryptedMessage.append(c);
            }
        }
        //trả về chuỗi đã mã hóa
        return encryptedMessage.toString();
    }
//---------------------------------------------------------
    private String Decrypted(String ciphertext, String keyword) throws IOException {
        //tạo chuỗi giải mã
        StringBuilder decryptedMessage = new StringBuilder();
        //duyệt các ký tự đã mã hóa
        for (int i = 0, j = 0; i < ciphertext.length(); i++) { 
            char c= ciphertext.charAt(i); 
            // Giải mã ký tự và thêm vào chuỗi giải mã (đối với chữ cái thường)
            if (Character.isLetter (c)) {
                char base = 'a';
                char keyChar = keyword.charAt(j);
                // Kiểm tra xem ký tự là chữ cái in hoa
                if (Character.isUpperCase(c)){
                    base = 'A';
                    keyChar = Character.toUpperCase(keyChar);
                }
                else {
                    keyChar = Character.toLowerCase(keyChar);
                }
                //thêm vào chuỗi giải mã
                //(c -keyChar+ 26) trừ khóa và công 26 để đảm bảo giá trị không âm
                //(c -keyChar+ 26) % 26 + base) đảm bảo giá trị trong khoảng 0-25 để chuyển về mã ASCII
                char decryptedChar =(char) ((c -keyChar+ 26) % 26 + base); 
                decryptedMessage.append(decryptedChar);
                //duyệt từng ký tự
                j = (j+1)% keyword.length();
            } else {
                // Giữ nguyên ký tự nếu không phải là chữ cái
                decryptedMessage.append(c);
            }
        }
        //trả về chuỗi đã giải mã
        return decryptedMessage.toString();
    }
//---------------------------------------------------------    
    private static String indexHello(String inputString) {
        String searchString = "HELLO";
        String[] tu = inputString.split(" ");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < tu.length; i++) {
            if (tu[i].equals(searchString)) {
                result.append(i + 1).append(",");
            }
        }
        if (result.toString().isBlank() || result.toString().isEmpty()) {
            return "not found word HELLO";
        }
        return result.substring(0, result.length() - 1) + ".";
    }
//-------------------------------------------------------
    private DatagramPacket receive() throws IOException {
        socket = new DatagramSocket(PORT);
        byte[] buffer = new byte[65507];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        return packet;
    }
//---------------------------------------------------------
    public void binaryWrite(String path, String content) throws IOException {
        //kiểm tra file tồn tại hay chưa
        File file = new File(path);
        if (!file.exists()) {
            //tạo file mới
            file.createNewFile();
            System.out.println("Da tao file nhi phan moi!");
        }
        try {
            //chuyển nội dung sang kiểu Bytes
            byte[] data = content.getBytes();
            //liên kết với tệp
            FileOutputStream fos = new FileOutputStream(file);
            //ghi dữ liệu vào tệp
            fos.write(data, 0, data.length);
            fos.flush();
            fos.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
//---------------------------------------------------------
    public String binaryRead(String path) throws IOException {
        File file = new File(path);
        FileInputStream fis = null;
        String content = "";
        byte[] data = new byte[2048];
        int length;
        try {
            //liên kết với
            fis = new FileInputStream(file);
            //data: mang, 0, 2048: đoc tối đa; 
            length = fis.read(data, 0, 2048);
            //lưu số byte thực vào mảng data
            content = new String(data, 0, length);

            fis.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return content;
    }
//---------------------------------------------------------
    public void textWrite(String path, String content) throws IOException {
        File file = new File(path);
        if (!file.exists()) {
            file.createNewFile();
            System.out.println("Da tao file van ban moi!");
        }
        try {
            //tạo dối tượng để mở 1 file đã được chỉ định
            FileWriter writer = new FileWriter(file);
            //cung cấp bộ đệm
            BufferedWriter buffer = new BufferedWriter(writer);
            //ghi nội dung
            buffer.write(content);
            //đóng bộ đệm để giải phóng tài nguyên và lưu tệp
            buffer.close();
        } catch (Exception ex) {
            System.out.println("Loi ghi file: " + ex);
        }
    }
//---------------------------------------------------------
    public String textRead(String path) throws IOException {
        String line = "";
        try {
            File f = new File(path);
            //đọc nội dung
            FileReader fr = new FileReader(f);
            //cung cấp bộ đệm 
            BufferedReader br = new BufferedReader(fr);
            //đọc nội dung 
            line = br.readLine();
            //đóng 
            fr.close();
            br.close();
        } catch (Exception ex) {
            System.out.println("Loi doc file: " + ex);
        }
        return line;    //trả nội dung đã đọc 
    }
//---------------------------------------------------------
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Server().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
//---------------------------------------------------------
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBinary;
    private javax.swing.JButton btnListen;
    private javax.swing.JButton btnText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField txtKey;
    private javax.swing.JTextField txtResult;
    // End of variables declaration//GEN-END:variables
}
